import json
import re
import sqlite3
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'.git', '.hvigor', '.idea', 'build', 'oh_modules', '__pycache__'}
def source_files():
    return [p for p in ROOT.rglob('*') if p.is_file() and not EXCLUDED.intersection(p.relative_to(ROOT).parts)]
SOURCE = (ROOT / 'entry/src/main/ets/data/JournalStore.ets').read_text()
# Exercise actual SQL strings, rather than a separately maintained implementation.
SQL = re.findall(r"""executeSql\((?:'([^']*)'|"([^"]*)"|`([^`]*)`)""", SOURCE)
SQL = [next(x for x in group if x) for group in SQL]
def find(prefix):
    return next(s for s in SQL if s.startswith(prefix))

class StoreTests(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(':memory:')
        for prefix in ['CREATE TABLE IF NOT EXISTS settings', 'INSERT OR IGNORE', 'CREATE TABLE IF NOT EXISTS events']:
            self.conn.execute(find(prefix))
    def tearDown(self):
        self.conn.close()
    def gate(self, enabled):
        self.conn.execute(find('UPDATE settings'), [int(enabled)])
    def append(self, detail='touch', timestamp='2026-10-19T06:00:00.000Z'):
        self.conn.execute(find('INSERT INTO events'), [timestamp, 'app', 'touch_up', detail])
        self.conn.execute(find('DELETE FROM events WHERE'))
    def count(self):
        return self.conn.execute('SELECT COUNT(*) FROM events').fetchone()[0]
    def test_default_paused(self):
        self.append()
        self.assertEqual(self.count(), 0)
    def test_pause_blocks_late_callbacks_and_resume(self):
        self.gate(True); self.append('first')
        self.gate(False); self.append('late callback')
        self.assertEqual(self.count(), 1)
        self.gate(True); self.append('resumed')
        self.assertEqual(self.count(), 2)
    def test_retention_is_latest_20000(self):
        self.gate(True)
        for i in range(20003):
            self.append(str(i))
        self.assertEqual(self.count(), 20000)
        self.assertEqual(self.conn.execute('SELECT detail FROM events ORDER BY id LIMIT 1').fetchone()[0], '3')
    def test_payload_is_bound_not_executable(self):
        self.gate(True); self.append("中文\n'); DROP TABLE events; --")
        self.assertEqual(self.count(), 1)
    def test_export_order_does_not_truncate_to_ui(self):
        self.gate(True)
        for i in range(225): self.append(str(i))
        query = re.search(r"querySql\('([^']*FROM events[^']*)'", SOURCE).group(1)
        ui = list(self.conn.execute(query, [200]))
        exported = list(reversed(list(self.conn.execute(query, [20000]))))
        self.assertEqual(len(ui), 200); self.assertEqual(len(exported), 225)
        self.assertEqual(exported[0][4], '0'); self.assertEqual(exported[-1][4], '224')
    def test_clear_leaves_recording_paused(self):
        self.gate(True); self.append()
        self.gate(False); self.conn.execute('DELETE FROM events'); self.append('late')
        self.assertEqual(self.count(), 0)
    def test_database_reopen_keeps_logs(self):
        with tempfile.TemporaryDirectory() as d:
            path = str(Path(d) / 'journal.db')
            disk = sqlite3.connect(path)
            self.conn.commit(); self.conn.backup(disk); disk.close()
            disk = sqlite3.connect(path)
            self.assertEqual(disk.execute("SELECT value FROM settings WHERE key='recording'").fetchone()[0], 0)
            disk.close()

class SessionTests(unittest.TestCase):
    tearDown = StoreTests.tearDown
    gate = StoreTests.gate
    append = StoreTests.append
    def setUp(self):
        StoreTests.setUp(self)
        self.conn.execute(find('CREATE TABLE IF NOT EXISTS sessions'))
    def start(self, time='2026-10-19T07:00:00Z'):
        self.conn.execute(find('INSERT INTO sessions (started_at,first_event)'), [time])
        self.gate(True)
    def stop(self):
        self.gate(False)
        self.conn.execute(find('UPDATE sessions SET'), ['2026-10-19T08:00:00Z'])
    def records(self, session):
        query = re.search(r'querySql\(`(SELECT e.id[^`]+)`', SOURCE).group(1)
        return list(self.conn.execute(query, [session]))
    def test_recordings_do_not_overlap(self):
        self.start(); self.append('session1'); self.stop()
        self.start(); self.append('session2'); self.stop()
        self.assertEqual([r[4] for r in self.records(1)], ['session1'])
        self.assertEqual([r[4] for r in self.records(2)], ['session2'])
    def test_empty_recording_does_not_absorb_later_events(self):
        self.start(); self.stop()
        self.start(); self.append('later'); self.stop()
        self.assertEqual(self.records(1), [])
        self.assertEqual(len(self.records(2)), 1)
    def test_legacy_events_migrate_once(self):
        self.gate(True); self.append('old'); self.gate(False)
        migrate = find('INSERT INTO sessions (started_at,ended_at')
        self.conn.execute(migrate)
        self.conn.execute("INSERT OR IGNORE INTO settings VALUES ('sessions_migrated',1)")
        self.conn.execute(migrate)
        self.assertEqual(self.conn.execute('SELECT COUNT(*) FROM sessions').fetchone()[0], 1)
        self.assertEqual(self.records(1)[0][4], 'old')
        self.conn.execute('DELETE FROM sessions'); self.conn.execute('DELETE FROM events')
        self.conn.execute(migrate)
        self.assertEqual(self.conn.execute('SELECT COUNT(*) FROM sessions').fetchone()[0], 0)
    def test_restart_closes_open_recording_and_preserves_events(self):
        self.start(); self.append('before restart'); self.stop()
        self.assertEqual(len(self.records(1)), 1)
        self.assertNotEqual(self.conn.execute('SELECT ended_at FROM sessions').fetchone()[0], '')
        self.append('late callback')
        self.assertEqual(len(self.records(1)), 1)

class ProjectTests(unittest.TestCase):
    def test_json_and_module_references(self):
        for path in [p for p in source_files() if p.suffix in {'.json', '.json5'}]:
            json.loads(path.read_text())
        module = json.loads((ROOT / 'entry/src/main/module.json5').read_text())['module']
        self.assertEqual([p['name'] for p in module['requestPermissions']], ['ohos.permission.CUSTOM_SCREEN_CAPTURE'])
        profile = json.loads((ROOT / 'entry/src/main/resources/base/profile/accessibility_config.json').read_text())
        self.assertEqual(profile['accessibilityCapabilities'], ['retrieve'])
        for ext in module['extensionAbilities']:
            self.assertTrue((ROOT / 'entry/src/main' / ext['srcEntry']).exists())
        for ability in module['abilities']:
            self.assertTrue((ROOT / 'entry/src/main' / ability['srcEntry']).exists())
        pages = json.loads((ROOT / 'entry/src/main/resources/base/profile/main_pages.json').read_text())['src']
        for page in pages:
            self.assertTrue((ROOT / 'entry/src/main/ets' / (page + '.ets')).exists())
    def test_no_sensitive_artifacts(self):
        blocked = {'.p12', '.p7b', '.cer', '.db', '.hap'}
        self.assertFalse([p for p in source_files() if p.suffix in blocked])

if __name__ == '__main__': unittest.main()
